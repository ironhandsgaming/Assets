player_manager.AddValidModel( "Blade Wolf", "models/mgrr/flaymi/bladewolf.mdl" );
list.Set( "PlayerOptionsModel", "Blade Wolf", "models/mgrr/flaymi/bladewolf.mdl" );