player_manager.AddValidModel( "Cat Bartender", "models/pacagma/bartender/cat_bartender_player.mdl" );
player_manager.AddValidHands( "Cat Bartender", "models/pacagma/bartender/c_arms_bartenderkitty.mdl", 0, "00000000" )
player_manager.AddValidModel( "Cat Cellist", "models/pacagma/cellist/cat_cellist_player.mdl" );
player_manager.AddValidHands( "Cat Cellist", "models/pacagma/cellist/c_arms_cellistkitty.mdl", 0, "00000000" )
player_manager.AddValidModel( "Cat Pianist", "models/pacagma/pianist/cat_pianist_player.mdl" );
player_manager.AddValidHands( "Cat Pianist", "models/pacagma/pianist/c_arms_pianistkitty.mdl", 0, "00000000" )
player_manager.AddValidModel( "Cat Singer", "models/pacagma/singer/cat_singer_player.mdl" );
player_manager.AddValidHands( "Cat Singer", "models/pacagma/singer/c_arms_singerkitty.mdl", 0, "00000000" )
